package by.fsc.showcase;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowcaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
